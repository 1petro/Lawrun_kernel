#!/system/bin/sh

echo /sys/devices/platform/kcal_ctrl.0/kcal - (256 256 256) - Controls R/G/B Multipliers
echo /sys/devices/platform/kcal_ctrl.0/kcal_min - (0) - Controls minimum RGB Multiplier value
echo /sys/devices/platform/kcal_ctrl.0/kcal_enable - (1) - Enables/Disables RGB Multiplier Control
echo /sys/devices/platform/kcal_ctrl.0/kcal_invert - (1) - Enables/Disables Display Inversion Mode
echo /sys/devices/platform/kcal_ctrl.0/kcal_sat - (272) - Controls saturation intensity - use 128 for grayscale mode
echo /sys/devices/platform/kcal_ctrl.0/kcal_hue - (0) - Controls display hue - may have issues with msm8x26 in the higher values
echo /sys/devices/platform/kcal_ctrl.0/kcal_val - (255) - Controls display value
echo /sys/devices/platform/kcal_ctrl.0/kcal_cont - (264) - Controls display contrast